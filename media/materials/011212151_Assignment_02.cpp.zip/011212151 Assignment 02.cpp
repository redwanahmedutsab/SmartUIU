#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

struct proc {
    int no, at, bt, pri, status, ct, tat, wt;
};

struct proc read(int i, float p) {
    struct proc p_new;
    p_new.no = i;
    p_new.at = 0;
    p_new.bt = rand() % ((int)p) + 1;
    p_new.pri = rand() % (int)p + 1;
    p_new.status = 0;
    return p_new;
}

int main() {
    int n;
    float p;
    struct proc p_array[50];

    cout << "Enter the probability of process arrival (p): ";
    cin >> p;

    cout << "Enter the number of processes (n): ";
    cin >> n;

    cout << "\n<--Non-Preemptive Priority Scheduling Algorithm-->\n";

    srand(time(0));

    int time = 0;
    int total_processes = 0;
    float avg_tat = 0, avg_wt = 0;
    int max_tat = 0, max_tat_index = -1;
    int max_wt = 0, max_wt_index = -1;

    for (int step = 0; step < 50; step++) {
        float rand_prob = (float)rand() / RAND_MAX;

        if (rand_prob <= p && total_processes < n) {
            p_array[total_processes] = read(total_processes + 1, p);
            total_processes++;
            cout << "Time " << time << ": New process P" << p_array[total_processes - 1].no << " arrived with burst time " << p_array[total_processes - 1].bt << " and priority " << p_array[total_processes - 1].pri << ".\n";
        }

        if (total_processes > 0) {
            int highest_priority_index = -1;
            int highest_priority = p + 1;

            for (int i = 0; i < total_processes; i++) {
                if (p_array[i].status == 0 && p_array[i].pri < highest_priority) {
                    highest_priority = p_array[i].pri;
                    highest_priority_index = i;
                }
            }

            if (highest_priority_index != -1) {
                cout << "Time " << time << ": Process P" << p_array[highest_priority_index].no << " is running.\n";
                p_array[highest_priority_index].status = 1;
                p_array[highest_priority_index].ct = time + p_array[highest_priority_index].bt;
                p_array[highest_priority_index].tat = p_array[highest_priority_index].ct;
                p_array[highest_priority_index].wt = p_array[highest_priority_index].tat - p_array[highest_priority_index].bt;

                if (p_array[highest_priority_index].tat > max_tat) {
                    max_tat = p_array[highest_priority_index].tat;
                    max_tat_index = highest_priority_index;
                }

                if (p_array[highest_priority_index].wt > max_wt) {
                    max_wt = p_array[highest_priority_index].wt;
                    max_wt_index = highest_priority_index;
                }

                time += p_array[highest_priority_index].bt;

                cout << "Time " << time << ": Process P" << p_array[highest_priority_index].no << " is completed.\n";
            }
        }

        avg_tat = 0;
        avg_wt = 0;
        for (int i = 0; i < total_processes; i++) {
            avg_tat += p_array[i].tat;
            avg_wt += p_array[i].wt;
        }
        avg_tat /= total_processes;
        avg_wt /= total_processes;
    }

    cout << "\nAverage Turnaround Time: " << avg_tat << endl;
    cout << "Average Waiting Time: " << avg_wt << endl;

    if (max_tat_index != -1)
        cout << "Max Turnaround Time: " << max_tat << " (Process P" << p_array[max_tat_index].no << ")\n";
    else
        cout << "Max Turnaround Time: None\n";

    if (max_wt_index != -1)
        cout << "Max Waiting Time: " << max_wt << " (Process P" << p_array[max_wt_index].no << ")\n";
    else
        cout << "Max Waiting Time: None\n";

    cout << "\nSimulation finished.\n";

    return 0;
}